import UIKit

class FourButtonsViewController: UIViewController {
override func viewDidLoad() {
super.viewDidLoad()
// Do any additional setup after loading the view.
}

@IBAction func firstButtonTapped( sender: Any) {
    print("Shoulder")
}

@IBAction func secondButtonTapped( sender: Any) {
print("Second bodypart")
}

    
@IBAction func thirdButtonTapped( sender: Any) {
    print("Third Bodypart")
}

@IBAction func fourthButtonTapped( sender: Any) {
    print("Fourth Bodypart")
}

}
