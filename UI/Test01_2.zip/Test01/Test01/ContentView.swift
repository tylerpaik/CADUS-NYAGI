import UIKit
import SwiftUI

struct ContentView: View {
    var body: some View {
        ViewControllerRepresenter()
    }
}

struct ViewControllerRepresenter: UIViewControllerRepresentable {
    func makeUIViewController(context: UIViewControllerRepresentableContext<ViewControllerRepresenter>) -> UIViewController {
        let storyboard = UIStoryboard(name: "Storyboard", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TwoButtons") as! Test01.TwoButtonsViewController
        return vc
    }
    func updateUIViewController(_ uiViewController: UIViewController, context: UIViewControllerRepresentableContext<ViewControllerRepresenter>) {
    }
}

