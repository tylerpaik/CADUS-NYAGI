//
//  Test01App.swift
//  Test01
//
//  Created by Kaden Hawley on 12/18/22.
//

import SwiftUI

@main
struct Test01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
